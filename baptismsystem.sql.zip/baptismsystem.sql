-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 11, 2022 at 05:42 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `baptismsystem`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `baptist`
-- 

CREATE TABLE `baptist` (
  `Reg_number` varchar(20) NOT NULL,
  `DateOfBaptism` date NOT NULL,
  `ChristianName` text NOT NULL,
  `Surname` text NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Father` text NOT NULL,
  `Mother` text NOT NULL,
  `GodParent` text NOT NULL,
  `Residence` text NOT NULL,
  `Priest` text NOT NULL,
  `Observation` text NOT NULL,
  PRIMARY KEY  (`Reg_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `baptist`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `usertable`
-- 

CREATE TABLE `usertable` (
  `fname` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `usertable`
-- 

